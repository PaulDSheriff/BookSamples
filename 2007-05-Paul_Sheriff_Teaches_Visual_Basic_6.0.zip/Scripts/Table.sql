Print 'Creating table tblEmployees'
Go
CREATE TABLE tblEmployees
(
      lEmp_id int NOT NULL,
   sFirst_nm char(20) NULL,
   szLast_nm varchar(25) NULL,
   szStreet1_ad varchar(35) NULL,
   szCity_nm varchar(25) NULL,
   sState_cd char(2) NULL,
   lState_id int NULL,
   sZip_cd char(10) NULL,
   sPhone_no char(14) NULL,
   szEMail_ad varchar(100) NULL,
   sSex_type char(1) NULL,
   lEmpType_id int NULL,
   sSSN_tx char(11) NULL,
   dtBirth_dt datetime NULL,
   cSalary_amt money NULL,
   dtStart_dt datetime NULL,
   boolActive_fl smallint NULL,
   dtEnd_dt datetime NULL,
   boolHealth_fl smallint NULL,
   bool401k_fl smallint NULL,
   boolBonus_fl smallint NULL,
   sLastUpdate_id char(16) NULL,
   dtLastUpdate_dt datetime NULL,
   iConcurrency_id smallint NULL
   , CONSTRAINT EmpPK 
   PRIMARY KEY NONCLUSTERED (   lEmp_id)
)
Go

Print 'Creating table tblEmployeesRollback'
Go
CREATE TABLE tblEmployeesRollback
(
      lEmp_id int NOT NULL,
   sFirst_nm char(20) NULL,
   szLast_nm varchar(25) NULL,
   szStreet1_ad varchar(35) NULL,
   szCity_nm varchar(25) NULL,
   sState_cd char(2) NULL,
   lState_id int NULL,
   sZip_cd char(10) NULL,
   sPhone_no char(14) NULL,
   szEMail_ad varchar(100) NULL,
   sSex_type char(1) NULL,
   lEmpType_id int NULL,
   sSSN_tx char(11) NULL,
   dtBirth_dt datetime NULL,
   cSalary_amt money NULL,
   dtStart_dt datetime NULL,
   boolActive_fl smallint NULL,
   dtEnd_dt datetime NULL,
   boolHealth_fl smallint NULL,
   bool401k_fl smallint NULL,
   boolBonus_fl smallint NULL,
   sLastUpdate_id char(16) NULL,
   dtLastUpdate_dt datetime NULL,
   iConcurrency_id smallint NULL
   , CONSTRAINT EmpRollBackPK 
   PRIMARY KEY NONCLUSTERED (   lEmp_id)
)
Go

Print 'Creating table tblEmpTypes'
Go
CREATE TABLE tblEmpTypes
(
      lEmpType_id int NOT NULL,
   szEmployee_type varchar(50) NULL,
   cSalary_min money NULL,
   cSalary_max money NULL,
   sLastUpdate_id char(16) NULL,
   dtLastUpdate_dt datetime NULL,
   iConcurrency_id smallint NULL
   , CONSTRAINT EmpTypePK 
   PRIMARY KEY NONCLUSTERED (   lEmpType_id)
)
Go

Print 'Creating table tblHealthCare'
Go
CREATE TABLE tblHealthCare
(
      lHealth_id int NOT NULL,
   szHealth_nm varchar(50) NULL,
   iWaitingPeriod_amt smallint NULL,
   sType_cd char(16) NULL,
   sLastUpdate_id char(16) NULL,
   dtLastUpdate_dt datetime NULL,
   iConcurrency_id smallint NULL
   , CONSTRAINT HealthCarePK 
   PRIMARY KEY NONCLUSTERED (   lHealth_id)
)
Go

Print 'Creating table tblNotes'
Go
CREATE TABLE tblNotes
(
      lNotes_id int NOT NULL,
   szTable_nm varchar(50) NULL,
   lTable_id int NULL,
   szShortDesc_tx varchar(50) NULL,
   szNotes_tx Text NULL,
   sLastUpdate_id char(16) NULL,
   dtLastUpdate_dt datetime NULL,
   iConcurrency_id smallint NULL
   , CONSTRAINT NotesPK 
   PRIMARY KEY NONCLUSTERED (   lNotes_id)
)
Go

Print 'Creating table tblStates'
Go
CREATE TABLE tblStates
(
      lState_id int NOT NULL,
   sState_cd char(2) NULL,
   szState_desc varchar(50) NULL,
   sRegion_cd char(20) NULL,
   sLastUpdate_id char(16) NULL,
   dtLastUpdate_dt datetime NULL,
   iConcurrency_id smallint NULL
   , CONSTRAINT StatePK 
   PRIMARY KEY NONCLUSTERED (   lState_id)
)
Go

Print 'Creating table tblTableIDs'
Go
CREATE TABLE tblTableIDs
(
      szTable_nm varchar(40) NOT NULL,
   lNext_id int NULL,
   sLastUpdate_id char(16) NULL,
   dtLastUpdate_dt datetime NULL,
   iConcurrency_id smallint NULL
   , CONSTRAINT TablePK 
   PRIMARY KEY NONCLUSTERED (   szTable_nm)
)
Go

Print 'Creating table tblUsers'
Go
CREATE TABLE tblUsers
(
      lUser_id int NOT NULL,
   szLast_nm varchar(30) NULL,
   szFirst_nm varchar(30) NULL,
   sLogin_id char(16) NOT NULL,
   sPassword_tx char(16) NULL,
   lGroup_id int NULL,
   sLastUpdate_id char(16) NULL,
   dtLastUpdate_dt datetime NULL,
   iConcurrency_id smallint NULL
   , CONSTRAINT UserPK 
   PRIMARY KEY NONCLUSTERED (   lUser_id)
)
Go

