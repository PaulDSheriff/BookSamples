Print 'Creating Index lEmpType_id on the table tblEmployees'
Go
CREATE INDEX idx_lEmpType_id
ON tblEmployees (lEmpType_id)

GO

Print 'Creating Index lGroup_id on the table tblUsers'
Go
CREATE INDEX idx_lGroup_id
ON tblUsers (lGroup_id)

GO

Print 'Creating Index sLogin_id on the table tblUsers'
Go
CREATE UNIQUE INDEX idx_sLogin_id
ON tblUsers (sLogin_id)

GO

